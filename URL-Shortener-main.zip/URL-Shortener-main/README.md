# URL Shortener 🔗

A simple tool to generate shortened URLs.

## Features
- 🎨 Convert long URLs to short ones

## How to Use
1. Run `python shortener.py`

## License
MIT License
